/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import com.sun.xml.rpc.processor.modeler.j2ee.xml.emptyType;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.bl.EmployeeTempLocal;

/**
 *
 * @author THEKISO MTSHANYELO
 */
public class EmployeeTempServlet extends HttpServlet {

    @EJB EmployeeTempLocal etl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String name = request.getParameter("name");
        Integer temp = Integer.parseInt(request.getParameter("temperature"));

        Boolean valid = etl.employeeTemp(temp);

        updateSession(session, valid);
        
        request.setAttribute("name", name);
        request.setAttribute("temperature", temp);
        
        RequestDispatcher disp = request.getRequestDispatcher("emp_temp_outcome.jsp");
        disp.forward(request, response);
    }

    private void updateSession(HttpSession session, boolean valid) {

        int countHighTempEmp ,countLowTempEmp ;

        countLowTempEmp = (Integer) session.getAttribute("count_low_temp_emp");
            countLowTempEmp++;
            session.setAttribute("count_low_temp_emp", countLowTempEmp);
            
        if (valid = false) {
        
            countHighTempEmp = (Integer) session.getAttribute("count_high_temp_emp");
            countHighTempEmp++;
            session.setAttribute("count_high_temp_emp", countHighTempEmp);
        }

    }

}
